public class HeapChecker {



    //must check if both heaps have the same size (except for one added or removed)
    //must check if both heaps have the same elements (except for one added or removed)

    /**
     * checks if the new heap is still a valid heap (according to the conditions below) with an element added to it.
     * @param hOrig
     * @param elt
     * @param hAdded
     * @return boolean
     */
    public boolean addEltValidator(IHeap hOrig, int elt, IBinTree hAdded) {
        //cannot use addElt in this function. find another way to add data
        if (hAdded.isHeap() && hOrig.checkIfAllElementsAreInBothHeaps(hAdded) && checkSizeOfAddedHeap(hOrig, hAdded) && hAdded.hasElt(elt)) {
            return true;
        }
        return false;
    }


    /**
     * checks if the new heap is still a valid heap (according to the conditions below) with an element removed from it.
     * @param hOrig
     * @param elt
     * @param hRemoved
     * @return boolean
     */
    public boolean remMinEltValidator(IHeap hOrig,  IBinTree hRemoved) {
        if (hRemoved.isHeap() && hOrig.checkifAllElementsButRootMatch(hRemoved) && checkSizeOfRemovedHeap(hOrig,hRemoved)) {
            return true;
        }
        return false;
    }

    /**
     * Checks the size of the added heap
     * @param hOrig
     * @param hAdded
     * @return boolean
     */
    public boolean checkSizeOfAddedHeap(IHeap hOrig, IBinTree hAdded){
        if (hAdded.size() == hOrig.size() + 1) {
            return true;
        }
        return false;
    }

    /**
     * checks the size of the removed element heap
     * @param hOrig
     * @param hRemoved
     * @return boolean
     */
    public boolean checkSizeOfRemovedHeap(IHeap hOrig, IBinTree hRemoved) {
        if (hRemoved.size() == hOrig.size() - 1) {
            return true;
        }
        return false;
    }

}


/*

THIS IS WHAT DEFINES A HEAP:

it is a heap

the result contain all the elements from the original heap

the new element has been added (addEltTester) or the smallest element removed (remMinEltTester)

No elements are in the result that were not in the original
 */