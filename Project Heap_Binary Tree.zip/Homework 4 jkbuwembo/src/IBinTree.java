import javax.xml.crypto.Data;
import java.lang.Math;

public interface IBinTree {
    // determines whether element is in the tree
    boolean hasElt(int e);
    // returns number of nodes in the tree; counts duplicate elements as separate items
    int size();
    // returns depth of longest branch in the tree
    int height();

    boolean isValidRoot(int root);

    /**
     * This method determines if the data of a tree is a heap.
     * @return boolean
     */
    boolean isHeap();

    boolean checkIfAllElementsAreInBothHeaps(IBinTree secondTree);

    boolean checkifAllElementsButRootMatch(IBinTree hRemoved);

}


