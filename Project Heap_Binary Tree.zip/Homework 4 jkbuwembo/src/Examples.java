import org.junit.*;
import static org.junit.Assert.*;

public class Examples {


    HeapChecker HT = new HeapChecker();


    @Test
    public void testIfResultIsAHeapAddEltValidator(){
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(22,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(15,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(12,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(10,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);

        assertTrue(HT.addEltValidator(myHeap2,13, myHeap2.addElt(13)));
        //Tests if the result is a heap for the AddEltValidator Method
    }

    @Test
    public void testIfNotAHeapAddEltValidator() {
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap2 = new DataHeap(14, emptyHeap, emptyHeap);
        DataHeap myHeap3 = new DataHeap(16, emptyHeap, emptyHeap);
        DataHeap myHeap1 = new DataHeap(2, myHeap2, myHeap3);

        MtBT emptyBT = new MtBT();
        DataBT myBT4 = new DataBT(4, emptyBT, emptyBT);
        DataBT myBT2 = new DataBT(14, myBT4, emptyBT);
        DataBT myBT3 = new DataBT(16, emptyBT, emptyBT);
        DataBT myBT1 = new DataBT(2, myBT2, myBT3);
        
        
        //for false heaps, write them in the form of dataBT.

        assertFalse(HT.addEltValidator(myHeap1,4, myBT1));
        //Tests if the result is NOT a heap for the AddEltValidator Method
    }

    @Test
    public void testIfAddedElementIsNotDetectedAddEltValidator() {
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(35,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(16,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(12,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(10,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);


        assertFalse(HT.addEltValidator(myHeap2,5, myHeap2.addElt(92)));

        //Tests if the added element is not detected for the AddEltValidator Method.
        //The added element is 92, but 5 is not detected.
    }

    @Test
    public void testIfSomeOfTheOtherElementsAreNotDetectedAddEltValidator() {
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(118,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(96,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(18,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(12,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);

        MtBT emptyBT = new MtBT();
        DataBT myBT6 = new DataBT(118,emptyBT,emptyBT);
        DataBT myBT5 = new DataBT(96,emptyBT,emptyBT);
        DataBT myBT3 = new DataBT(18,myBT5,myBT6);
        DataBT myBT4 = new DataBT(13,emptyBT,emptyBT);
        DataBT myBT2 = new DataBT(8,myBT3,myBT4);

        assertFalse(HT.addEltValidator(myHeap2,13, myBT2));
        //Tests if some of the elements are not detected for the AddEltValidator Method.
        //Example: 13 was not in the original heap, but when it was added, 12 was not detected.

    }

    @Test
    public void detectResultWithExtraneousElementsAddEltValidator() {
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(34,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(23,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(18,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(12,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);

        MtBT emptyBT = new MtBT();
        DataBT myBT6 = new DataBT(34,emptyBT,emptyBT);
        DataBT myBT5 = new DataBT(23,emptyBT,emptyBT);
        DataBT myBT3 = new DataBT(18,myBT5,myBT6);
        DataBT myBT4 = new DataBT(12,emptyBT,emptyBT);
        DataBT myBT8 = new DataBT(8,emptyBT,emptyBT);
        DataBT myBT7 = new DataBT(4,myBT4,myBT8);
        DataBT myBT2 = new DataBT(2,myBT3,myBT7);

        assertFalse(HT.addEltValidator(myHeap2,4, myBT2));

        //checks for extraneous values with the add element validator method applied.
        //example, when 4 was added to the new heap, 2 is extraneous.
    }

    @Test
    public void testIfResultIsAHeapRemoveEltValidator(){
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(22,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(15,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(12,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(10,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);
        
        MtBT emptyBT = new MtBT();
        DataBT myBT6 = new DataBT(22,emptyBT,emptyBT);
        DataBT myBT5 = new DataBT(15,emptyBT,emptyBT);
        DataBT myBT3 = new DataBT(12,myBT5,myBT6);
        DataBT myBT4 = new DataBT(10,myBT3,emptyBT);


        assertTrue(HT.remMinEltValidator(myHeap2, myBT4));

        //checks to see if java can detect a correct heap when removed minimum element method
        //is applied.

        
    }

    @Test
    public void  testIfNotAHeapRemMinEltValidator(){
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap2 = new DataHeap(14, emptyHeap, emptyHeap);
        DataHeap myHeap3 = new DataHeap(16, emptyHeap, emptyHeap);
        DataHeap myHeap1 = new DataHeap(2, myHeap2, myHeap3);

        MtBT emptyBT = new MtBT();
        DataBT myBT2 = new DataBT(14, emptyBT, emptyBT);
        DataBT myBT3 = new DataBT(16, myBT2, emptyBT);


        assertFalse(HT.remMinEltValidator(myHeap1, myBT3));

        //This example checks to see if the java can detect an incorrect heap when
        //the removed minimum element validator method is applied.

    }
    
    @Test
    public void testIfRemovedElementIsNotDetectedRemMinEltValidator(){
        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(35,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(16,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(12,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(10,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);

        MtBT emptyBT = new MtBT();
        DataBT myBT6 = new DataBT(35,emptyBT,emptyBT);
        DataBT myBT5 = new DataBT(16,emptyBT,emptyBT);
        DataBT myBT4 = new DataBT(10,emptyBT,myBT6);
        DataBT myBT2 = new DataBT(8,myBT5,myBT4);

        assertFalse(HT.remMinEltValidator(myHeap2, myBT2));

        //detects if the removed element is not detected.
        //example: 12 is not detected because it was never in the original heap
    }

    @Test
    public void testIfSomeOfTheOtherElementsAreNotDetectedRemMinEltValidator(){

        //Tests if some of the other elements are not detected
        // for example, when eight was removed, 10 somehow appeared and could not be detected.

        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(118,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(96,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(18,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(12,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);

        MtBT emptyBT = new MtBT();
        DataBT myBT6 = new DataBT(118,emptyBT,emptyBT);
        DataBT myBT5 = new DataBT(96,emptyBT,emptyBT);
        DataBT myBT3 = new DataBT(18,myBT5,myBT6);
        DataBT myBT4 = new DataBT(12,emptyBT,emptyBT);
        DataBT myBT2 = new DataBT(10,myBT3,myBT4);

        assertFalse(HT.remMinEltValidator(myHeap2, myBT2));

    }

    @Test
    public void detectResultWithExtraneousElementsRemMinValidator() {
        //checks if there are extraneous elements in the heap
        //for example, when 8 was removed in the Dataheap, the DataBT somehow
        //has an element 2, which is extraneous.

        MtHeap emptyHeap = new MtHeap();
        DataHeap myHeap6 = new DataHeap(34,emptyHeap,emptyHeap);
        DataHeap myHeap5 = new DataHeap(23,emptyHeap,emptyHeap);
        DataHeap myHeap3 = new DataHeap(18,myHeap5,myHeap6);
        DataHeap myHeap4 = new DataHeap(12,emptyHeap,emptyHeap);
        DataHeap myHeap2 = new DataHeap(8,myHeap3,myHeap4);

        MtBT emptyBT = new MtBT();
        DataBT myBT6 = new DataBT(34,emptyBT,emptyBT);
        DataBT myBT5 = new DataBT(23,emptyBT,emptyBT);
        DataBT myBT3 = new DataBT(18,emptyBT,myBT6);
        DataBT myBT4 = new DataBT(12,emptyBT,emptyBT);
        DataBT myBT7 = new DataBT(4,myBT5,myBT4);
        DataBT myBT2 = new DataBT(2,myBT3,myBT7);

        assertFalse(HT.remMinEltValidator(myHeap2, myBT2));

    }
    
    
}
