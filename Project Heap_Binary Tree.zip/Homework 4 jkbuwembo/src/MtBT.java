public class MtBT implements IBinTree {
    MtBT() {
    }


    // returns false since empty tree has no elements
    public boolean hasElt(int e) {
        return false;
    }

    // returns 0 since enpty tree has no elements
    public int size() {
        return 0;
    }

    // returns 0 since empty tree has no branches
    public int height() {
        return 0;
    }

    /**
     * Since there is no data to compare in an empty tree, the route given is automatically valid.
     * @param data
     * @return boolean
     */
    @Override
    public boolean isValidRoot(int data) {
        return true;
    }

    /**
     * Since there is no data to compare in an empty tree, the tree will always be a heap.
     * @return boolean
     */

    //if the heap is empty case code
    public boolean isHeap() {
        //since there is no number to compare the node to
        //it returns true.
        return true;

    }

    /**
     * Since there is no data to compare in an empty tree, in both heaps, the elements will be the same initially.
     * @param secondTree
     * @return boolean
     */
    @Override
    public boolean checkIfAllElementsAreInBothHeaps(IBinTree secondTree) {
        return true;
    }

    /**
     * Since there is no data to compare in an empty tree, the heaps compared will have the same elements when the root is skipped.
     * @param hRemoved
     * @return boolean
     */
    @Override
    public boolean checkifAllElementsButRootMatch(IBinTree hRemoved) {
        return true;
    }



}
