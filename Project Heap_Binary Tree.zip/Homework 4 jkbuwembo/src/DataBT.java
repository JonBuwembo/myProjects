public class DataBT implements IBinTree {
    int data;
    IBinTree left;
    IBinTree right;

    DataBT(int data, IBinTree left, IBinTree right) {
        this.data = data;
        this.left = left;
        this.right = right;
    }

    // an alternate constructor for when both subtrees are empty
    DataBT(int data) {
        this.data = data;
        this.left = new MtBT();
        this.right = new MtBT();
    }

    // determines whether this node or node in subtree has given element
    public boolean hasElt(int e) {
        return this.data == e || this.left.hasElt(e) || this.right.hasElt(e);
    }

    // adds 1 to the number of nodes in the left and right subtrees
    public int size() {
        return 1 + this.left.size() + this.right.size();
    }

    // adds 1 to the height of the taller subtree
    public int height() {
        return 1 + Math.max(this.left.height(), this.right.height());
    }

    /**
     * determines if the parameter integer value "root" is a valid root for a heap
     * @param root
     * @return boolean
     */
    public boolean isValidRoot(int root) {
        if (root <= this.data && this.left.isValidRoot(root) && this.right.isValidRoot(root)) {
            return true;
        }
        return false;
    }

    /**
     * This method determines if the data of a tree is a heap.
     * @return boolean
     */
    public boolean isHeap() { //case if the heap is not empty
        if (this.isValidRoot(this.data) && this.left.isHeap() && this.right.isHeap()) {
            return true;
        }
        return false;
        //is root smaller than the rest of the heap?
        //takes in the data
        //compares the data with the other nodes in the heap
        //leftSubtree.isHeap(data)
        //rightSubtree.isHeap(data)
    }

    /**
     * Compares two trees to check if they both have the same elements.
     * @param secondTree
     * @return boolean
     */

    public boolean checkIfAllElementsAreInBothHeaps(IBinTree secondTree) {
        //if the element in one heap is in another return true
        if (secondTree.hasElt(this.data) && this.left.checkIfAllElementsAreInBothHeaps(secondTree) && this.right.checkIfAllElementsAreInBothHeaps(secondTree)) {
            return true;
        }
        return false;
    }


    //make a method to skip root element and check if rest of elements in the new binary tree

    /**
     * checks if all the elements in the removed heap are the same as the original.
     * It skips over the root, since it was removed.
     * @param hRemoved
     * @return boolean
     */
    public boolean checkifAllElementsButRootMatch(IBinTree hRemoved) {
        if (this.left.checkIfAllElementsAreInBothHeaps(hRemoved) && this.right.checkIfAllElementsAreInBothHeaps(hRemoved)){
            return true;
        }
        return false;
        //this.data for root
        //this.left
        //this.right
        //implement method checkIfAllElementsInBothHeapsWhenRemoved()
    }


}

