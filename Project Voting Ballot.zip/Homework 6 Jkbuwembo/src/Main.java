public class Main {
    public static void main(String[] args) throws RedundantCandidateException {

        //Test screen method

        VotingData vd = new VotingData();
        PollingDevice pd = new PollingDevice(vd);


            vd.nominateCandidate("gompei");
            vd.nominateCandidate("husky");
            vd.nominateCandidate("ziggy");



        pd.screen();
        System.out.println("Votes for Gompei: " + vd.countVotesForFirstChoice("gompei"));
        System.out.println("Votes for Husky: " + vd.countVotesForFirstChoice("husky"));
        System.out.println("Votes for ziggy: " + vd.countVotesForFirstChoice("ziggy"));

    }
}
