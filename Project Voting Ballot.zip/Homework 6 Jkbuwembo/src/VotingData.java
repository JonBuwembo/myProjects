import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class VotingData {
    private LinkedList<String> ballot = new LinkedList<String>();


    //Constructor for VotingData Class
    VotingData() {}

    public LinkedList<String> getBallot(){
        return ballot;
    }

    //Hashmaps for the different choices (also represent first, second, third place hashmaps)
    private HashMap<String,Integer> firstChoiceMap = new HashMap<>();
    private HashMap<String,Integer> secondChoiceMap = new HashMap<>();
    private HashMap<String,Integer> thirdChoiceMap = new HashMap<>();


    /**
     * Stores the candidates choices into their respective hashmaps and counts the number of votes for each candidate.
     * @param firstChoice first choice candidate
     * @param secondChoice second choice candidate
     * @param thirdChoice third choice candidate
     * @throws CandidateChosenMoreThanOnceException if there is a candidate voted for in the first second or third choice more than once.
     * @throws CandidateNotFoundException if the voted candidate isn't in the ballot.
     */

    public void submitVote(String firstChoice, String secondChoice, String thirdChoice) throws CandidateChosenMoreThanOnceException, CandidateNotFoundException{
        //initialize the hashmaps to have an integer (count of the votes) to zero.

        //threw CandidateNotFoundException before CandidateChosenMoreThanOnceException
        if (!ballot.contains(firstChoice)){
            throw new CandidateNotFoundException(firstChoice);
        }
        if (!ballot.contains(secondChoice)){
            throw new CandidateNotFoundException(secondChoice);
        }
        if (!ballot.contains(thirdChoice)){
            throw new CandidateNotFoundException(thirdChoice);
        }
        //knows which name that is voted for twice
        if (firstChoice.equals(secondChoice)) {
            throw new CandidateChosenMoreThanOnceException(firstChoice);
        }
        if (secondChoice.equals(thirdChoice)) {
            throw new CandidateChosenMoreThanOnceException(secondChoice);
        }
        if (thirdChoice.equals(firstChoice)) {
            throw new CandidateChosenMoreThanOnceException(thirdChoice);
        }



        //stores a single voter's choice in your data structure
        firstChoiceMap.put(firstChoice, firstChoiceMap.get(firstChoice) + 1); //countVotesForA choice counts how many times a user chose a name to be in that choice
        secondChoiceMap.put(secondChoice,secondChoiceMap.get(secondChoice) + 1);
        thirdChoiceMap.put(thirdChoice,thirdChoiceMap.get(thirdChoice) + 1);
    }



    //Purpose: This functions puts in the candidates that people will vote on.

    /**
     * Adds a candidate to the ballot and initializes the first, second and third choice Maps.
     * @param candidateName name of candidate
     * @throws RedundantCandidateException if the candidate is already in the ballot.
     */
    public void nominateCandidate(String candidateName) throws RedundantCandidateException {

        if(ballot.contains(candidateName)){
            throw new RedundantCandidateException(candidateName);
        }
        ballot.add(candidateName);

        firstChoiceMap.put(candidateName, 0);
        secondChoiceMap.put(candidateName, 0);
        thirdChoiceMap.put(candidateName, 0);
        //This functions DOES work for tests **** (CORRECT)
    }

    /**
     * picks the winner if the winner has more than 50% of votes in first place.
     * @return String (winning candidate)
     */

    public String pickWinnerMostFirstChoice() {

        String candidateWithMostVotes = "EmptyCandidateDummyVar";
        //returns the name of the winning candidate who has more than 50% of the first place votes.
        //
        for (Map.Entry<String, Integer> element : firstChoiceMap.entrySet()){
            if (element.getValue() > 0.50 * getTheTotalOfAllVotesInFirstPlace()){
                return element.getKey();
            }
            else {
                candidateWithMostVotes = "*Requires Runoff Poll*";
            }
        }
            //if a single candidate has more votes than the other.

        return candidateWithMostVotes;
    }


    /**
     * Helper method to get the most points for an individual candidate to apply to pickWinnerMostAgreeableMethod.
     * @param candidateName name of the candidate.
     * @return int (the most points for a Candidate)
     */
    public int returnMostPointsForOneCandidate(String candidateName) {
        //get the highest number of points for a single candidate
        int theMostPointsForThisCandidate = 0;
        if (this.firstChoiceMap.get(candidateName) > theMostPointsForThisCandidate ) {
            theMostPointsForThisCandidate = this.firstChoiceMap.get(candidateName);
        }
        if (this.secondChoiceMap.get(candidateName) > theMostPointsForThisCandidate ) {
            theMostPointsForThisCandidate = this.secondChoiceMap.get(candidateName);
        }
        if (this.thirdChoiceMap.get(candidateName) > theMostPointsForThisCandidate ) {
            theMostPointsForThisCandidate = this.thirdChoiceMap.get(candidateName);
        }
        return theMostPointsForThisCandidate;
    }

    /**
     * picks which winner is most agreeable by returning the candidate with the highest votes considering all hashmaps (helper above).
     * @return String (a winning Candidate)
     */
    public String pickWinnerMostAgreeable() {
        String theWinner = null;
        int theMostPoints = 0;
        for (String s: ballot) {
            if(this.returnMostPointsForOneCandidate(s) > theMostPoints) {
                theMostPoints = this.returnMostPointsForOneCandidate(s);
                theWinner = s;
            }
        }
        //returns the name of the winning candidate with the most points following formula on the HW assignment page.
        //if there is a tie, return the name of any one of the winners.
        return theWinner;
    }


    /**
     * Helper method to get the total of all first place votes.
     * @return int (number of votes)
     */
    public int getTheTotalOfAllVotesInFirstPlace(){
        int numVotes = 0;
        for (Map.Entry<String, Integer> element : firstChoiceMap.entrySet()) {
            numVotes = numVotes + element.getValue();
        }
        return numVotes;
    }

    /**
     * This method counts all votes for a candidate in first place.
     * @param forcand name of the candidate.
     * @return int
     */

    public int countVotesForFirstChoice(String forcand) {
        int numvotes = 0;
        for (Map.Entry<String, Integer> element : firstChoiceMap.entrySet()) {
            if (element.getKey().equals(forcand)) {
                numvotes = numvotes + 1;
            }
        }
        return numvotes;
    }


}



