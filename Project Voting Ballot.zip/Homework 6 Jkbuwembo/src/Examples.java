import org.junit.Test;

import java.util.LinkedList;

import static org.junit.Assert.*;


public class Examples {

    //FirstExample
    VotingData setExampleOne() {

    VotingData vd = new VotingData();

    // put candidates on the ballot
    try {

        LinkedList<String> ballot = new LinkedList<>();

        vd.nominateCandidate("gompei");
        vd.nominateCandidate("husky");
        vd.nominateCandidate("ziggy");
        vd.nominateCandidate("Tomas");
        //adds to the ballot

    } catch (Exception e) {}

    // cast votes

    try {

        vd.submitVote("gompei", "husky", "ziggy");
        vd.submitVote("gompei", "ziggy", "husky");
        vd.submitVote("gompei", "husky", "ziggy");
        vd.submitVote("Tomas", "gompei", "ziggy");


    } catch (Exception e) {}

    return(vd);

}

//Second example

    VotingData setExampleTwo() {

        VotingData vd = new VotingData();

        // put candidates on the ballot
        try {

            vd.nominateCandidate("gompei");
            vd.nominateCandidate("husky");
            vd.nominateCandidate("ziggy");
            vd.nominateCandidate("Tomas");
            //adds to the ballot

        } catch (Exception e) {}

        // cast votes

        try {

            vd.submitVote("gompei", "husky", "ziggy");
            vd.submitVote("Tomas", "ziggy", "husky");
            vd.submitVote("gompei", "husky", "ziggy");
            vd.submitVote("husky", "gompei", "ziggy");


        } catch (Exception e) {}

        return(vd);

    }


//Third example
VotingData setExampleThree() {

    VotingData vd = new VotingData();

    // put candidates on the ballot
    try {

        vd.nominateCandidate("gompei");
        vd.nominateCandidate("husky");
        vd.nominateCandidate("ziggy");
        vd.nominateCandidate("Tomas");
        //adds to the ballot

    } catch (Exception e) {}

    // cast votes

    try {

        vd.submitVote("gompei", "Tomas", "ziggy");
        vd.submitVote("gompei", "ziggy", "husky");
        vd.submitVote("Tomas", "husky", "ziggy");
        vd.submitVote("husky", "Tomas", "ziggy");


    } catch (Exception e) {}

    return(vd);

}


//Fourth Example
VotingData setExampleFour() {

    VotingData vd = new VotingData();

    // put candidates on the ballot
    try {

        vd.nominateCandidate("gompei");
        vd.nominateCandidate("husky");
        vd.nominateCandidate("ziggy");
        vd.nominateCandidate("Tomas");
        //adds to the ballot

    } catch (Exception e) {}

    // cast votes

    try {

        vd.submitVote("gompei", "Tomas", "ziggy");
        vd.submitVote("gompei", "ziggy", "husky");
        vd.submitVote("Tomas", "Tomas", "ziggy");
        vd.submitVote("husky", "Tomas", "ziggy");


    } catch (Exception e) {}

    return(vd);

}

//Fifth Example
VotingData setExampleFive() {

    VotingData vd = new VotingData();

    // put candidates on the ballot
    try {

        vd.nominateCandidate("gompei");
        vd.nominateCandidate("husky");
        vd.nominateCandidate("ziggy");
        vd.nominateCandidate("Tomas");
        //adds to the ballot

    } catch (Exception e) {}

    // cast votes

    try {

        vd.submitVote("gompei", "Tomas", "ziggy");
        vd.submitVote("gompei", "ziggy", "husky");
        vd.submitVote("Tomas", "Tomas", "ziggy");
        vd.submitVote("spiderMan", "Tomas", "ziggy");




    } catch (Exception e) {}

    return(vd);

}

    // now run a test on a specific election
    @Test
    public void testPickWinnerMostFirstChoice() {
        assertEquals("gompei", this.setExampleOne().pickWinnerMostFirstChoice());
    }

    @Test
    public void testPickWinnerMostFirstChoiceWithPollRunOff(){
        assertEquals("*Requires Runoff Poll*", this.setExampleTwo().pickWinnerMostFirstChoice());
    }

    @Test
    public void testPickWinnerMostAgreeable() {
        assertEquals("ziggy", this.setExampleThree().pickWinnerMostAgreeable());
    }

    @Test(expected = CandidateChosenMoreThanOnceException.class)
    public void testExceptionForCandidateChosenMoreThanOnce() throws CandidateChosenMoreThanOnceException, CandidateNotFoundException {
        this.setExampleFour().submitVote("Tomas", "Tomas", "ziggy");
    }

    @Test(expected = CandidateNotFoundException.class)
    public void testExceptionForACandidateNotFound() throws CandidateChosenMoreThanOnceException, CandidateNotFoundException {
        this.setExampleFive().submitVote("spiderMan", "Tomas", "ziggy");
    }

    @Test(expected = RedundantCandidateException.class)
    public void testExceptionForARedundantCandidate() throws RedundantCandidateException {
        this.setExampleFive().nominateCandidate("husky");
    }



}
