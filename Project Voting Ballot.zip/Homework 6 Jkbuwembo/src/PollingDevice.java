
import java.util.Scanner;

public class PollingDevice {

    private Scanner keyboard = new Scanner(System.in);
    private VotingData dataObj;


    PollingDevice(VotingData dataObj){
        this.dataObj = dataObj;
    }

    /**
     * screen method brings to application some other methods written.
     * creates an interactive panel where the user can vote for candidates through
     * a series of prompted questions. Implements try, catch block where some exceptions will be applied.
     * @catch CandidateChosenMoreThanOnceException, CandidateNotFoundException
     * @returns Void
     */
    public void screen() {

        this.printBallot();
        System.out.println("Who do you want to vote for first?");
        String candidateOne = keyboard.next();
        System.out.println("You voted for " + candidateOne);

        System.out.println("Who do you want to vote for second?");
        String candidateTwo = keyboard.next();
        System.out.println("You voted for " + candidateTwo);

        System.out.println("Who do you want to vote for third?");
        String candidateThree = keyboard.next();
        System.out.println("You voted for " + candidateThree);


        try {
            dataObj.submitVote(candidateOne, candidateTwo, candidateThree);


        }
        catch (CandidateNotFoundException de){
            System.out.println("Would you like to add this candidate to the ballot y/n?");
            String yesOrNo = keyboard.next();
            if (yesOrNo.equals("Y") || yesOrNo.equals("y")) {
                this.addWriteIn(de.getCandidateName());
                this.screen();
            }

        }
        catch (CandidateChosenMoreThanOnceException ce) {
            System.out.println("you cannot vote for " + ce.getCandidateName() + " again");
            this.screen();
        }
    }


    /**
     * This method prints the ballot of candidates.
     * Returns nothing.
     */
    public void printBallot() {
        System.out.println("The candidates are ");
        for (String s : dataObj.getBallot()) {
            System.out.println(s);
        }
    }


    /**
     * Implements a try, catch block for redundancy.
     * checks if the user wants to vote for another candidate if they input a candidate that wasn't in the ballot.
     * @Param aCandidateName
     * @return void
     */



    public void addWriteIn(String aCandidateName) {
        try {
            dataObj.nominateCandidate(aCandidateName);
            System.out.println( "candidate was added successfully");
        }
        catch (RedundantCandidateException re) {
            System.out.println("This candidate already exists");

        }

    }

}
