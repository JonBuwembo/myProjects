public class CandidateNotFoundException extends Exception{
    private String candidateName;

    public CandidateNotFoundException(String candidateName){
       this.candidateName = candidateName;

    }

    /**
     * Getter method for candidate name. Gets candidate name.
     * @return String
     */
    public String getCandidateName(){
        return candidateName;
    }


}
