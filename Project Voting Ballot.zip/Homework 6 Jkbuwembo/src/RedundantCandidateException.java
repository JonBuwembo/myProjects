public class RedundantCandidateException extends Exception{

    private String candidatesName;
    public RedundantCandidateException(String candidatesName){

        this.candidatesName = candidatesName;
    }

    //didn't need a getter here.


}
