public class CandidateChosenMoreThanOnceException extends Exception{
    private String candidateName;
    public CandidateChosenMoreThanOnceException(String candidateName) {
        this.candidateName = candidateName;
    }

    /**
     * Getter method for the candidate name.
     * @return String
     */
    public String getCandidateName(){
        return candidateName;
    }
}
